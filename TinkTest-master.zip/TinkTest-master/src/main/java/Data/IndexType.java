package Data;


/**
 * Enum with all index names
 */
public enum IndexType {
    RSI,
    NVI,
    PVI
}
