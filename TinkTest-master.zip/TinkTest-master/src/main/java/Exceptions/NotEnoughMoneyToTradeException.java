package Exceptions;


/**
 * Throws when user hasn't got enough money for trading
 */
public class NotEnoughMoneyToTradeException extends Exception{
}
