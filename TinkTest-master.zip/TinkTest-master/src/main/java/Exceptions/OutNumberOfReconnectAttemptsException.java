package Exceptions;

/**
 * Throws when number of reconnection attempts is out of limits
 */
public class OutNumberOfReconnectAttemptsException extends Exception{
}
