enum TRADE_DIRECTIONS  {
  SELL = "sell",
  BUY = "buy",
}

export default TRADE_DIRECTIONS;
