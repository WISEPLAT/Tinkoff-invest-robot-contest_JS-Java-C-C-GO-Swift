enum TradeAPIs {
  BINANCE = "BINANCE",
  ALPACA = "ALPACA",
  TINKOFF = "TINKOFF",
  BACKTEST = "BACKTEST"
}

export default TradeAPIs;
