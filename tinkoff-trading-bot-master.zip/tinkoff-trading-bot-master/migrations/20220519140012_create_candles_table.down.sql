drop table if exists candles;
