drop table if exists instruments;
drop type if exists instrument_type;
