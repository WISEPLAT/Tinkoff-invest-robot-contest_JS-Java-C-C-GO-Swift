drop table if exists shares;
