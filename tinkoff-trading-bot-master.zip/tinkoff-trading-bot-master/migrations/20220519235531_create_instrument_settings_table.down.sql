drop table if exists instrument_settings;
