drop table if exists trading_strategies;
