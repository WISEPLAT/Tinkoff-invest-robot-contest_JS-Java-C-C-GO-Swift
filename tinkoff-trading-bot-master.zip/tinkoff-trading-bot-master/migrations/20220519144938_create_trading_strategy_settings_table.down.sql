drop table if exists trading_strategy_settings;
