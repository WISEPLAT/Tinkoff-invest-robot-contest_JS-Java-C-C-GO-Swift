drop table if exists currencies;
