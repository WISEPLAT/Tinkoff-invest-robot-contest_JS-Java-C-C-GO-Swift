<template>
  <div class="uk-container uk-margin-medium-top">
    <h1 class="uk-heading-line"><span>Profile</span></h1>
  </div>
</template>
