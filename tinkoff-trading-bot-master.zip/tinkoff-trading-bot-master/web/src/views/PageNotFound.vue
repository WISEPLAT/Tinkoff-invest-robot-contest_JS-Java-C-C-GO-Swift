<template>
  <div class="uk-child-width-1-1@s uk-text-center" uk-grid>
    <div>
      <div class="uk-background-default uk-padding uk-panel">
        <p class="uk-h4">404</p>
      </div>
    </div>
  </div>
</template>
