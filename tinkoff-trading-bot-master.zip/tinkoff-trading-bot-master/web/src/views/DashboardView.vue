<script setup>
import InstrumentsManagment from "@/components/elements/dashboard/InstrumentsManagment.vue";
</script>

<template>
  <div class="uk-container uk-margin-medium-top">
    <h1 class="uk-heading-line"><span>Dashboard</span></h1>
    <InstrumentsManagment />
  </div>
</template>
