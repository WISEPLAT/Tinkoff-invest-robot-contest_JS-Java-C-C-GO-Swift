<template>
  <div class="uk-flex uk-flex-column">
    <button class="uk-button uk-button-default">+</button>
    <div class="uk-overflow-auto">
      <table class="uk-table uk-table-divider">
        <thead>
          <tr>
            <th>ID</th>
            <th>Trading Strategy</th>
            <th>Params</th>
            <th>Created at</th>
            <th>Status</th>
          </tr>
        </thead>
        <tbody>
          <tr>
            <td>123</td>
            <td>MVP</td>
            <td>{"sd":1,"spjb":023}</td>
            <td>23 Dec 2021</td>
            <td><input class="uk-checkbox" type="checkbox" checked></td>
          </tr>
          <tr>
            <td>123</td>
            <td>MVP</td>
            <td>{"sd":1,"spjb":023}</td>
            <td>23 Dec 2021</td>
            <td><input class="uk-checkbox" type="checkbox" checked></td>
          </tr>
          <tr>
            <td>123</td>
            <td>MVP</td>
            <td>{"sd":1,"spjb":023}</td>
            <td>23 Dec 2021</td>
            <td><input class="uk-checkbox" type="checkbox"></td>
          </tr>
          <tr>
            <td>123</td>
            <td>MVP</td>
            <td>{"sd":1,"spjb":023}</td>
            <td>23 Dec 2021</td>
            <td><input class="uk-checkbox" type="checkbox" checked></td>
          </tr>
          <tr>
            <td>123</td>
            <td>MVP</td>
            <td>{"sd":1,"spjb":023}</td>
            <td>23 Dec 2021</td>
            <td><input class="uk-checkbox" type="checkbox"></td>
          </tr>
          <tr>
            <td>123</td>
            <td>MVP</td>
            <td>{"sd":1,"spjb":023}</td>
            <td>23 Dec 2021</td>
            <td><input class="uk-checkbox" type="checkbox" checked></td>
          </tr>
        </tbody>
      </table>
    </div>
  </div>
</template>
