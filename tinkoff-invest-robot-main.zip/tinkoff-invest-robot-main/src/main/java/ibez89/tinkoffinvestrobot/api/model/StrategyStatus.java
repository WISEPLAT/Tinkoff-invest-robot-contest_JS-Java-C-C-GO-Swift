package ibez89.tinkoffinvestrobot.api.model;

public enum StrategyStatus {

    ACTIVE,
    ARCHIVED
}
