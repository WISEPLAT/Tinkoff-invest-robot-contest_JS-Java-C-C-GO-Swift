package ibez89.tinkoffinvestrobot.api.model;

public enum OrderDirection {

    BUY,

    SELL
}
