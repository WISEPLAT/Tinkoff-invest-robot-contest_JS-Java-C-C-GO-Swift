package ibez89.tinkoffinvestrobot.api.model;

public enum OrderStatus {

    NEW,

    PLACED,

    FILLED,

    REJECTED,

    UNKNOWN
}
