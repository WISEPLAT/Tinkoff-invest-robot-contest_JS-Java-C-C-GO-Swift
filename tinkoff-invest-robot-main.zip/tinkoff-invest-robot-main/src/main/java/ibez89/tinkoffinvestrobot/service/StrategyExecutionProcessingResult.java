package ibez89.tinkoffinvestrobot.service;

public enum StrategyExecutionProcessingResult {

    RESCHEDULE,

    COMPLETE
}
