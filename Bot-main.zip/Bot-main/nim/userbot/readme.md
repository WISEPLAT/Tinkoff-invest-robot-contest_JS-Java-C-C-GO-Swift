<div align="center">

# Userbot
Automatiс friends addition

</div>


## Get Started
### Install
```bash
git clone https://github.com/linksplatform/Bot
cd Bot/nim/userbot
nimble install shizuka
```
