namespace TraderBot;

public enum Instrument
{
    Etf,
    Shares,
}