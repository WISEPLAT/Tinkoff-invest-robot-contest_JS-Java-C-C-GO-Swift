# Bot

## [VK bot](https://github.com/linksplatform/Bot/tree/main/python)
This bot is created for programmers by programmers. Features are: personal Karma tracking, programmer's personal information storage, Wikipedia access, GitHub Copilot access.
## [GitHub bot](https://github.com/linksplatform/Bot/tree/main/csharp/Platform.Bot)
Bot that can create "hello world" and have some other useful features.
## [Discord bot](https://github.com/linksplatform/Bot/tree/AddDiscrodBot/csharp/DiscordBot)
Bot that can add new programmers to LinksPlatform team from discord to GitHub's organization.
## [Trader bot](https://github.com/linksplatform/Bot/tree/main/csharp/TraderBot)
Scalper strategy implementation.
