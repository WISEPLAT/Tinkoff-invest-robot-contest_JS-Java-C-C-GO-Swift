//
//  GraphRouter.swift
//  TradeBot
//
//  Created by Денис Калугин on 16.05.2022.
//

final class GraphRouter {
    // MARK: - Properties

    // MARK: - Private properties

    // MARK: - Constants

    private enum Constants {

    }

    // MARK: - Func

    // MARK: - Private func
}

// MARK: - GraphRouterInput

extension  GraphRouter: GraphRouterInput {

}
