//
//  TradeBotRouter.swift
//  TradeBot
//
//  Created by Денис Калугин on 15.05.2022.
//

final class TradeBotRouter {
    // MARK: - Properties

    // MARK: - Private properties

    // MARK: - Constants

    private enum Constants {

    }

    // MARK: - Func

    // MARK: - Private func
}

// MARK: - TradeBotRouterInput

extension  TradeBotRouter: TradeBotRouterInput {

}
