//
//  TesterInteractor.swift
//  TradeBot
//
//  Created by Денис Калугин on 19.05.2022.
//

final class TesterInteractor {
    // MARK: - Properties

    weak var output: TesterInteractorOutput!

    // MARK: - Private properties

    // MARK: - Constants

    private enum Constants {

    }

    // MARK: - Func

    // MARK: - Private func
}

// MARK: - TesterInteractorInput

extension TesterInteractor: TesterInteractorInput {

}
