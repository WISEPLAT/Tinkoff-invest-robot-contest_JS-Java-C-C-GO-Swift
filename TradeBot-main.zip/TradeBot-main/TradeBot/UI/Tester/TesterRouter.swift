//
//  TesterRouter.swift
//  TradeBot
//
//  Created by Денис Калугин on 19.05.2022.
//

final class TesterRouter {
    // MARK: - Properties

    // MARK: - Private properties

    // MARK: - Constants

    private enum Constants {

    }

    // MARK: - Func

    // MARK: - Private func
}

// MARK: - TesterRouterInput

extension TesterRouter: TesterRouterInput {

}
