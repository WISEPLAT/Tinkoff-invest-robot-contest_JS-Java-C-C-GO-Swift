//
//  NSAttributedString+.swift
//  TradeBot
//
//  Created by Денис Калугин on 20.05.2022.
//

import Foundation

extension NSAttributedString {

    static let empty: NSAttributedString = NSAttributedString(string: .empty)
}
