//
//  Int+.swift
//  TradeBot
//
//  Created by Денис Калугин on 19.05.2022.
//

import Foundation

extension Int {

    var cgFloat: CGFloat {
        return CGFloat(self)
    }
}
