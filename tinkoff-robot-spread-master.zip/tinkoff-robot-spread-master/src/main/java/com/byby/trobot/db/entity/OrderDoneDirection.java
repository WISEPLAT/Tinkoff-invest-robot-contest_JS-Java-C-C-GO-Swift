package com.byby.trobot.db.entity;

public enum OrderDoneDirection {
    BUY,
    SELL,
    UNRECOGNIZED
}
