package dto

type StopAlgorithmRequest struct {
	AlgorithmId uint `form:"algorithmId"`
}
