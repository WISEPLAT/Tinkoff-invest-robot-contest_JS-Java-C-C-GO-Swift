package dto

type StatAlgoRequest struct {
	AlgorithmID uint `form:"algorithm_id"`
}
