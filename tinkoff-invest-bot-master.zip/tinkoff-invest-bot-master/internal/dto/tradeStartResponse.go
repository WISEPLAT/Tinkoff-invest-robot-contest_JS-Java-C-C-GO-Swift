package dto

type TradeStartResponse struct {
	Info        string
	AlgorithmID uint
}
