package baseoption

type Variable struct {
	Name string
}
