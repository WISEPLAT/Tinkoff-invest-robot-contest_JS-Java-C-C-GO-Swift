package ru.unclesema.ttb.model;

public enum UserMode {
    SANDBOX,
    MARKET,
    ANALYZE
}
