package ru.unclesema.ttb.strategy;

public enum StrategyDecision {
    BUY,
    SELL,
    NOTHING
}
