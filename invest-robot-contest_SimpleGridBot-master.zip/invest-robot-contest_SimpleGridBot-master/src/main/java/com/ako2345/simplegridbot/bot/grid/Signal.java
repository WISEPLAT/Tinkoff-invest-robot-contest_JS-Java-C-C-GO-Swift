package com.ako2345.simplegridbot.bot.grid;

public enum Signal {
    BUY, SELL, NONE
}