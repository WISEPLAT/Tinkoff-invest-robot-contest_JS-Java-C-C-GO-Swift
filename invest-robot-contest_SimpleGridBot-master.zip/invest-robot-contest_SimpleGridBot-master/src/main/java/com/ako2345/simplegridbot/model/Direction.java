package com.ako2345.simplegridbot.model;

public enum Direction {
    BUY, SELL
}