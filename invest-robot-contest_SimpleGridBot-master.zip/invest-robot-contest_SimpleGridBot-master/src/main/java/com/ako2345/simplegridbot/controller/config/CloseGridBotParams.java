package com.ako2345.simplegridbot.controller.config;

import lombok.Data;

@Data
public class CloseGridBotParams {

    boolean instrumentShouldBeSold;

}