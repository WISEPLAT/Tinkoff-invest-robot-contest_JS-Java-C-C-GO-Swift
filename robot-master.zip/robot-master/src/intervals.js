module.exports = {
  '1min': 'CANDLE_INTERVAL_1_MIN',
  '5min': 'CANDLE_INTERVAL_5_MIN',
  '10min': 'CANDLE_INTERVAL_15_MIN',
  'hour': 'CANDLE_INTERVAL_HOUR',
  'day': 'CANDLE_INTERVAL_DAY'
};