docker pull justdimmy/fintech:latest

# OR
# docker-compose pull app