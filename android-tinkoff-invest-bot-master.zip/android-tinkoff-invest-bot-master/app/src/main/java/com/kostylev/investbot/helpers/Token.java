package com.kostylev.investbot.helpers;

public class Token {
    public static final String tokenSandbox = "<token>";

    public static String getToken(){
        return tokenSandbox;
    }
}
