export { OpenAPIClient as TinkoffApiClient } from "@tinkoff/invest-js";
