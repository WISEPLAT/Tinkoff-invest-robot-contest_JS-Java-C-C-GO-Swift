<?php

return [
    'hostname' => 'localhost',
    'port' => 6379,
    'database' => 0,
];
