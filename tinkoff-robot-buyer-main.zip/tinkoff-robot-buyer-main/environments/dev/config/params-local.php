<?php

return [
    'email' => [
        'admin' => [],
    ],
    'url' => [
        'server' => 'https://trading.metaseller.local',
    ],
];
