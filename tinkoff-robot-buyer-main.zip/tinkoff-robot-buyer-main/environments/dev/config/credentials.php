<?php

return [
    'tinkoff_invest' => [
        'secret_key' => '',
        'account_id' => '',
    ],
];
