package ru.plotnikov.tinkoff.invest.strategies.events;

public interface ExchangeEvent {
}
