package ru.plotnikov.tinkoff.invest.strategies;

public enum Action {
    SELL,
    BUY
}
