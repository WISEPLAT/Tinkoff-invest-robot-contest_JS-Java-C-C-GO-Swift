package com.ildvild.tinkoffInvest.server.robots.exceptions;

public class RobotStateException extends Exception {

    public RobotStateException(String message) {
        super(message);
    }

}
