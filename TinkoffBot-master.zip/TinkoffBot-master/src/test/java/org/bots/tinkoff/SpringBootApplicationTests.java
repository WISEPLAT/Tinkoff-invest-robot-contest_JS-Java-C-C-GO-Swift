package org.bots.tinkoff;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringBootApplicationTests {

	@Test
	void contextLoads() {
	}

}
