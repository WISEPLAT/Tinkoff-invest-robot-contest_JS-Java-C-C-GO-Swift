package ru.abelogur.tininvestrobot.domain;

public enum OrderAction {
    OPEN,
    CLOSE,
}
