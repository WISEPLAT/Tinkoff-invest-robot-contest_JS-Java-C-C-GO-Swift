package ru.abelogur.tininvestrobot.domain;

public enum TradeType {
    LONG,
    SHORT
}
