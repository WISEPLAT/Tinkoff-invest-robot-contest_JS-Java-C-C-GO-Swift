package ru.abelogur.tininvestrobot.domain;

public enum OrderReason {
    SIGNAL_LONG,
    SIGNAL_SHORT,
    TAKE_PROFIT,
    STOP_LOSS
}
