package ru.abelogur.tininvestrobot.dto;

public enum BotEnv {
    SIMULATION,
    SANDBOX,
    REAL
}
