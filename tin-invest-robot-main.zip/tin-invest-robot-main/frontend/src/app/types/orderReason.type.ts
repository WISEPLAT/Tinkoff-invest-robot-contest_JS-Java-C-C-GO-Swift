export type OrderReasonType = 'SIGNAL_LONG' | 'SIGNAL_SHORT' | 'TAKE_PROFIT' | 'STOP_LOSS';
