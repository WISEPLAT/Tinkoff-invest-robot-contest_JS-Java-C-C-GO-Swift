export type BotEnvType = 'SIMULATION' | 'SANDBOX' | 'REAL';
