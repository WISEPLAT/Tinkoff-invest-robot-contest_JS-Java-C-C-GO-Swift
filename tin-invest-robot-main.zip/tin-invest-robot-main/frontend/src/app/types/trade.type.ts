export type TradeType = 'LONG' | 'SHORT';
