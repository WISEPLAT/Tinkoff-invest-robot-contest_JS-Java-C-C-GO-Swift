export const BROKERS = {
    TINKOFF: {
        name: 'Tinkoff',
        logo: '/tinkoff.svg',
        w: 90,
        h: 90,
    },
    FINAM: {
        name: 'Finam',
        logo: '/finam.png',
        w: 100,
        h: 100,
    },
    BINANCE: {
        name: 'Binance',
        logo: '/Binance.svg',
        w: 90,
        h: 100,
    },
};
