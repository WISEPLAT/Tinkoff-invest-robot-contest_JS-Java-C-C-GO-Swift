export declare type TinkoffCandleFormatted = {
  open: number;
  high: number;
  low: number;
  close: number;
  volume: number;
  time: Date;
  isCompelete: boolean;
};
