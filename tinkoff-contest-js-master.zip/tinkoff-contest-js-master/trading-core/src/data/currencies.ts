export enum Currencies {
  USD = 'USD',
  RUB = 'RUB',
  EUR = 'EUR',
  UNKNOWN = 'UNKNOWN'
}