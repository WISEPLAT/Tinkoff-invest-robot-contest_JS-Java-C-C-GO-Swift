package net.snatchlab.investmentfarm.actors;

public interface Repositioned {

  void reposition(int width, int height);

}
