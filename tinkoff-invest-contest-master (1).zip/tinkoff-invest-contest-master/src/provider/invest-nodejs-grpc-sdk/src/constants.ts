export const APP_NAME = 'suenot';
export const API_URL = 'invest-public-api.tinkoff.ru:443';
