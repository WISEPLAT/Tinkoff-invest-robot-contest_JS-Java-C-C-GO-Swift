package com.ako2345.simplegridbot.model;

public enum OrderStatus {
    NEW, FILL, CANCELLED, REJECTED, PARTIALLY_FILL
}